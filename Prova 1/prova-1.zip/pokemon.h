#pragma oce 

#include <iostream>
#include "pokemon.h"
#include "pokebola.h"
#include "treinador.h"
#include <string>
using std::cout, std::endl, std::string;

class Pokemon{
    public:
    Pokemon::Pokemon (string nome, string tipo, string som);

    void setNome(string nome);
    
    void setTipo(string tipo);
    
    void setSom(string som);
    
    string getNome() const;
    
    string getTipo() const;
    
    string getSom() const;
    
    string emitirSom() const;
    
    private:
    string n_nome;
    string n_tipo;
    string n_som;
};