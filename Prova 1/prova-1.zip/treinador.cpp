#include <iostream>
#include "pokemon.h"
#include "pokebola.h"
#include "treinador.h"
#include <string>

using std::cout, std::endl, std::string;

Treinador::Treinador(string nome = " ") {
    setNome(nome);
}

void setNome (string nome){
    n_n = nome;
}
    
string getNome (string nome) {
    return n_n;
}
    
void capturar (Pokemon *pokemon){
    //recebe o pokemon e guarda na pockebola 
    pockemon.pockebola->guardar();
}

void Treinador:: vai(string nome){
    if (nome == pokemon->nome){
        
        cout << pokemon->emitirsom();
    }
    else{
        cout << "Ooooops. Ainda não capturei esse pokemon!." << endl; 
}
    