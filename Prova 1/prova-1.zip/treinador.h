#pragma oce 

#include <iostream>
#include "pokemon.h"
#include "pokebola.h"
#include "treinador.h"
#include <string>

using std::cout, std::endl, std::string;

class Treinador:
    public:
    
    Treinador(string nome);
    
    void capturar (Pokemon *pokemon);

    private:
    
    string n_n; 
    Pokemon *pokemon;
    Pokebola *pokebola;
};