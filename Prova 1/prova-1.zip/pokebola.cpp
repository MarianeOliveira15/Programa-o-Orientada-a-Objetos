#include <iostream>
#include "pokemon.h"
#include "pokebola.h"

#include <string>
using std::cout, std::endl, std::string;

//pokemon esta dentro da pokebola, livro dentro da mala, agregação 

Pokebola::Pokebola(Pokemon *pokemon) pokemon(nullptr){
   
    void Pockebola guardar(Pokemon *pokemon){
        this->pokemon = ;
    }
}
