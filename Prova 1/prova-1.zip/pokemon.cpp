#include <iostream>
#include "pokemon.h"
#include "pokebola.h"
#include "treinador.h"
#include <string>
#include <format>
using std::cout, std::endl, std::string, std::format;

Pokemon::Pokemon (string nome, string tipo, string som){
    setNome(nome);
    setTipo(tipo);
    setSom(som);
}

void Pokemon::setNome(string nome) {
    n_nome = nome;
}

void Pokemon::setTipo(string tipo) {
    n_tipo = tipo;
}

void Pokemon::setSom(string som) {
    n_som = som;
}

string Pokemon:: getNome() const{
    return n_nome;
}

string Pokemon:: getTipo() const{
    return n_tipo;
}

string Pokemon:: getSom() const{
    return n_som;
}

string Pokemon:: emitirSom() const{
    return format("{}\n",getSom());
}


