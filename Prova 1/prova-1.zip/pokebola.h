#pragma oce 

#include <iostream>
#include "pokemon.h"
#include "pokebola.h"
#include "treinador.h"
#include <string>
using std::cout, std::endl, std::string;

class Pokebola (){
    public:
    void setPokemon (Pokemon *pokemon) {this->pokemon = pokemon;}
    
    private;
    Pokemon *pokemon;
}
